export interface Adresse {
  ville: string;
  codePostal: number;
  rue: string;
  numéro: string;
  étage: string;
}
